import React, { Component } from "react";

import './App.css';

import CVBuilder from "./containers/CVBuilder/CVBuilder";

class App extends Component {
  render() {
    return (
      <div id="cvBuilderApp" className="app-wrap">
        <CVBuilder />
      </div>
    );
  }
}

export default App;
