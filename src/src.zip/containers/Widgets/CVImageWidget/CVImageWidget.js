import React, { Component } from "react";

import classes from "./CVImageWidget.css";
import image from "../../../default-profile-2.webp";
class CVImageWidget extends Component {
  state = {
    url: "../../../default-profile.png"
  };
  imagePreviewRef = new React.createRef();

  render() {
    console.log(image);
    return (
      <div className={classes["cv-form-group"]}>
        <label htmlFor="cover-image" className={classes["big-label"]}>
          <div className={classes["cv-form-inner-group"]}>
            <div
              style={{ backgroundImage: `url(${image})` }}
              className={classes["cv-form-image-preview"]}
              ref={this.imagePreviewRef}
            ></div>

            <div className={classes["cv-form-image-uploader-container"]}>
              <input
                id="cover-image"
                className={classes["custom-file-input"]}
                type="file"
                accept="image/*"
                onChange={this.handleImageChanged}
              />
              <label
                htmlFor="cover-image"
                className={classes["cv-form-image-label"]}
              >
                Upload an Image
              </label>
            </div>
          </div>
        </label>
      </div>
    );
  }
}

export default CVImageWidget;
