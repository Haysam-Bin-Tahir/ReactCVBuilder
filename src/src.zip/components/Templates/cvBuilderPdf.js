import React, {useEffect} from "react";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Image
} from "@react-pdf/renderer";
import { render, wait } from "@testing-library/react";

const styles = StyleSheet.create({
  page: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: "3%"
  },
  // Section 1 styling
  mainSection1: {
    flexGrow: 2.5,
    flexBasis: 60,
    //backgroundColor: 'green',
    marginLeft: 30,
    marginRight: 30,
    flexDirection: "column"
  },
  mainSection1c1: {
    flexDirection: "row"
  },
  mainSection1C1MainPic: {
    //backgroundColor: "grey",
    borderRadius: 100,
    width: 60,
    height: 60,
    marginRight: 20
  },
  mainSection1C1MainText: {
    //backgroundColor: "pink",
  },
  mainSection1c2: {
    //backgroundColor: "orangered",
  },
  mainSection1c3: {
    //backgroundColor: "purple",
  },
  mainSection1C3Main: {
    //backgroundColor: "grey",
    flexDirection: "row"
  },
  mainSection1c4: {
    //backgroundColor: "silver",
  },
  mainSection1Text: {
    fontSize: 10,
    margin: 2
  },
  // Section 1 styling end

  //Section 2 styling
  mainSection2: {
    flexGrow: 1,
    flexBasis: 40,
    //backgroundColor: 'orange',
    flexDirection: "column"
  },
  mainSection2c1: {
    //backgroundColor: 'yellow',
  },
  mainSection2c2: {
    //backgroundColor: 'red',
    marginTop: 20
  },
  starSection: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginRight: 30
  },
  star: {
    width: 5,
    height: 5,
    borderRadius: 100,
    backgroundColor: "#0080FF"
  },
  mainSection2Text: {
    fontSize: 11,
    marginBottom: 10
  },
  // Section 2 styling end
  bigHeading: {
    color: "black",
    fontSize: 25,
    marginBottom: 2
  },
  mediumHeading: {
    color: "black",
    fontSize: 18,
    marginBottom: 10
  },
  primaryHeading: {
    fontSize: 15,
    color: "#0080FF",
    marginBottom: 10
  },
  secondaryHeading: {
    fontSize: 11,
    color: "#0080FF",
    marginBottom: 5
  },
  centerText: {
    textAlign: "center"
  },
  sectionMargin: {
    marginBottom: 30
  }
});

const Templatepdf = callbackFunction => {
    let props = {};
    props["_cvData"] = null;
    setInterval(() => {
        props["_cvData"] = {...callbackFunction.requestData()};
    }, 2500);
    return (
        <Document>
        {props["_cvData"] ? (
            <Page size="A4" style={styles.page}>
            <View style={styles.mainSection1}>
              <View style={{ ...styles.mainSection1c1, ...styles.sectionMargin }}>
                <View>
                  <Image
                    style={styles.mainSection1C1MainPic}
                    src="https://images.unsplash.com/photo-1503023345310-bd7c1de61c7d?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80"
                  ></Image>
                </View>
                <View style={styles.mainSection1C1MainText}>
                  <Text style={styles.bigHeading}>
                    {[props._cvData["first-name"] ? props._cvData["first-name"] : '', props._cvData["last-name"] ? props._cvData["last-name"] : ''].join(
                      " "
                    )}
                  </Text>
                  <Text style={styles.primaryHeading}>
                    {props._cvData["job-title"]}
                  </Text>
                  <Text style={styles.mainSection1Text}>
                    {props._cvData["city"] ? props._cvData["city"] : ""}{" "}
                    {props._cvData["country"] ? props._cvData["country"] : ""}
                  </Text>
                </View>
              </View>
              <View style={{ ...styles.mainSection1c2, ...styles.sectionMargin }}>
                {props._cvData["personal-statement"] ? (
                  <React.Fragment>
                    <Text style={styles.primaryHeading}>Profile</Text>
                    <Text style={styles.mainSection1Text}>
                      {props._cvData["personal-statement"]}
                    </Text>
                  </React.Fragment>
                ) : null}
              </View>
              {props._cvData["employment-history"] ? (
                props._cvData["employment-history"].length > 0 ? (
                  <View style={styles.mainSection1c3}>
                    <Text style={styles.primaryHeading}>Employment History</Text>

                    {props._cvData["employment-history"].map(ele => {
                      return (
                        <View
                          key={Math.random()}
                          style={{
                            ...styles.mainSection1C3Main,
                            ...styles.sectionMargin
                          }}
                        >
                          <View style={{ marginRight: 30, flexBasis: 150 }}>
                            <Text style={styles.secondaryHeading}>
                              {ele.duration.from ? ele.duration.from : null} -{" "}
                              {ele.duration.tillPresent
                                ? "Present"
                                : ele.duration.to
                                ? ele.duration.to
                                : null}
                            </Text>
                            <Text style={styles.mainSection1Text}>{ele.city}</Text>
                          </View>

                          <View>
                            <Text style={styles.mediumHeading}>
                              {ele["job-title"] ? ele["job-title"] : null}
                            </Text>
                            <Text style={styles.mainSection1Text}>
                              {ele["description"]}
                            </Text>
                          </View>
                        </View>
                      );
                    })}
                  </View>
                ) : null
              ) : null}
              <View style={{ ...styles.mainSection1c4, ...styles.sectionMargin }}>
                <Text style={styles.primaryHeading}>Education</Text>
                <View
                  style={{ ...styles.mainSection1C3Main, ...styles.sectionMargin }}
                >
                  <View style={{ marginRight: 30, flexBasis: 150 }}>
                    <Text style={styles.secondaryHeading}>May 2019 - May 2020</Text>
                    <Text style={styles.mainSection1Text}>Pakistan</Text>
                  </View>
                  <View>
                    <Text style={styles.mediumHeading}>BS Computer Science</Text>
                    <Text style={styles.mainSection1Text}>
                      This is first education detail
                    </Text>
                  </View>
                  <View></View>
                </View>
                <View style={styles.mainSection1C3Main}>
                  <View style={{ marginRight: 30, flexBasis: 150 }}>
                    <Text style={styles.secondaryHeading}>May 2019 - May 2020</Text>
                    <Text style={styles.mainSection1Text}>Pakistan</Text>
                  </View>
                  <View>
                    <Text style={styles.mediumHeading}>BS Computer Science</Text>
                    <Text style={styles.mainSection1Text}>
                      This is second education detail
                    </Text>
                  </View>
                  <View></View>
                </View>
              </View>
            </View>
            <View style={styles.mainSection2}>
              <View style={styles.mainSection2c1}>
                <Text style={styles.primaryHeading}>Details</Text>
                {props._cvData["e-mail"] ? (
                  <Text style={styles.mainSection2Text}>
                    {props._cvData["e-mail"]}
                  </Text>
                ) : null}
                <Text style={styles.mainSection2Text}>www.muzamildesigns.com</Text>
                {props._cvData["phone"] ? (
                  <Text style={styles.mainSection2Text}>
                    {props._cvData["phone"]}
                  </Text>
                ) : null}
                {props._cvData["address"] ? (
                  <Text style={styles.mainSection2Text}>
                    {props._cvData["address"]}
                  </Text>
                ) : null}
                {props._cvData["postal-code"] ? (
                  <Text style={styles.mainSection2Text}>
                    {props._cvData["postal-code"]}
                  </Text>
                ) : null}
                {props._cvData["driving-license"] ? (
                  <Text style={styles.mainSection2Text}>
                    {props._cvData["driving-license"]}
                  </Text>
                ) : null}
                {props._cvData["nationality"] ? (
                  <Text style={styles.mainSection2Text}>
                    {props._cvData["nationality"]}
                  </Text>
                ) : null}
              </View>
              <View style={styles.mainSection2c2}>
                <Text style={styles.primaryHeading}>Skills</Text>
                <View>
                  <Text style={styles.mainSection2Text}>Skill 1</Text>
                  <View style={styles.starSection}>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                    <Text style={styles.star}></Text>
                  </View>
                </View>
              </View>
            </View>
          </Page>

        ) : null}
      </Document>
      );
};
export default Templatepdf;
